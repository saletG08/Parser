module Lib
    ( someFunc
    ) where

import Text.Parsec
import Text.Parsec.Text (Parser)
import qualified Data.Text.IO as T
import AST
import Parser2 (statementsParser)

someFunc :: IO ()
someFunc = do
    input <- T.readFile "code.rvc"
    let result = parse statementsParser "" input
    case result of
        Left err -> print err
        Right statements -> print statements



{- import Text.Parsec (parse)
import Parser2 (literalsParser)
import qualified Data.Text.IO as TIO

someFunc :: IO ()
someFunc = do
    contents <- TIO.readFile "code.rvc"
    let result = parse literalsParser "" contents
    print result -}